//
// Created by fifthdimension on 2020/1/28.
//
#include "cocos2d.h"
#include "LogoScene.h"
#include "LoginScene.h"
#include "Common/Common.h"

USING_NS_CC;

Scene *LogoScene::createScene() {
    auto scene = Scene::create();
    auto layer = LogoScene::create();
    scene->addChild(layer);
    return scene;
}

// 被宏"CREATE_FUNC(LoginScene); "替代了。
//LogoScene *LogoScene::createLayer() {
//    auto pRet = new LogoScene();
//    if (pRet->init()) {
//        //release 和retain是配套的，释放管理是通过引用计数。
//        //每一个CCObject对象都有一个引用计数。retain()时引用计数+1，release()则-1.在release之后，若引用计数为0，便会调用delete this; 真正的释放自己的内存。
//        //CCObject新建的时候，引用计数默认为1.
//        pRet->autorelease(); // 采用引用计数方式自动管理对象
//        return pRet;
//    }
//    CCLOG("Func LogoScene::CreateLayer Error!");
//    pRet = nullptr;
//    delete pRet;
//    return nullptr;
//}

bool LogoScene::init() {
    do {
        /************************************************************************/
        /*				初始化数据库                                                                     */
        /************************************************************************/


        //初始化父类
        CC_BREAK_IF(Layer::init() == false);

        /************************************************************************/
        /*			背景图片                                                                     */
        /************************************************************************/
        //创建logo图片
        Sprite *pLogoBg = Sprite::create("ui/logo_bg.png");
        CC_BREAK_IF(pLogoBg == nullptr);
        pLogoBg->setPosition(SCREEN_CENTER);
        addChild(pLogoBg, enZOrderFront);


        /************************************************************************/
        /*			1.UI：联网，确认是否有网络                                                                     */
        /************************************************************************/
        bool isNetEnv = false;
        isNetEnv = true;
        if (isNetEnv) {
            //延迟1秒
            this->runAction(Sequence::create(
                    DelayTime::create(0.5f),
                    CallFunc::create(CC_CALLBACK_0(LogoScene::onChangeScene, this)),
                    NULL));
        } else {
            ////延迟2秒
            //this->runAction(CCSequence::create(
            //	CCDelayTime::create(1.f),
            //	CCCallFunc::create(this,callfunc_selector(CNFLogoScene::OnAddTipLayer)),
            //	NULL));
        }

        return true;
    } while (false);
    CCLOG("Fun LogoScene::Init Error!");
    return false;
}

//临时：切换场景
void LogoScene::onChangeScene() {
    do {
        //跳转到服务器选择界面
        Scene *pScene = LoginScene::createScene();
        CC_BREAK_IF(pScene == nullptr);
        Director::getInstance()->replaceScene(TransitionFade::create(20.f, pScene));

        return;
    } while (false);
    CCLOG("Fun CNFLogoScene::OnChangeScene Error!");
}
