//
// Created by fifthdimension on 2020/1/29.
//

#ifndef DEMOGAME_LOGINSCENE_H
#define DEMOGAME_LOGINSCENE_H

#include "Common/Common.h"

class LoginScene : public Layer, public MsgReceiver {
protected:
    enum {
        enTagLoading = 1,
        enTagServerNameLabel,
        enTagStudioLoginLayer,        //登陆层
        enTagStudioRegisterLayer,    //注册层
    };
    int m_nLoadResNum;                //资源加载数
    int m_nLoadResTotalNum;            //资源加载总数

    int m_nCurrentServerID;            //当前服务器ID
    int m_nServerTotalNum;            //服务器的总数量
public:
    static Scene *createScene();
    CREATE_FUNC(LoginScene); // 这个宏生成的方法是出Layer的,而且还有使用自动管理的操作

    void onMsg(int nMsgID, void *pInfo, int nSize) override;

protected:
    bool init() override;
    void onEnter() override;

    // 资源预加载
    void loadRes();

    void onLoadResCallBack(Texture2D* texture);        //回调：资源加载

    //异步加载骨骼资源的回调
    void onLoadArmatureData(float percent);

    virtual void switchSceneUI();                    //在这里加载该图层专用的资源

    void testCC();

    //---------------登录页按钮回调----------------
//    void onClick_Enter(Ref *pSender, TouchEventType type);                 //开始游戏
//    void onClick_ServerSelect(CCObject *pSender, TouchEventType type);          //选择服务器
//    void onClick_SwitchToRegister(CCObject *pSender, TouchEventType type);      //跳转到注册页
//    void onClick_Login(CCObject *pSender, TouchEventType type);                 //登录
//    void onTextFieldEvent_Account(CCObject *pSender, TextFiledEventType type);


    //---------------注册页按钮回调----------------
//    void onClick_BackToLogin(CCObject *pSender, TouchEventType type);           //跳转到登录页
//    void onClick_Register(CCObject *pSender, TouchEventType type);              //注册
};


#endif //DEMOGAME_LOGINSCENE_H
