//
// Created by fifthdimension on 2020/1/29.
//

#ifndef DEMOGAME_LOADINGLAYER_H
#define DEMOGAME_LOADINGLAYER_H

#include "cocos2d.h"

USING_NS_CC;

class LoadingLayer : public LayerColor {
protected:
    enum {
        enTagPro = 1, enTagLight, enTagLabel
    };
public:
    CREATE_FUNC(LoadingLayer);
    void setProgress(float fRate);

protected:
    EventListenerTouchOneByOne* _touchListener;

    bool init() override;
    //触摸
    bool onTouchBegan(Touch *pTouch, Event *pEvent) override;
    void onTouchMoved(Touch *pTouch, Event *pEvent) override;
    void onTouchEnded(Touch *pTouch, Event *pEvent) override;

    void onExit() override;
};


#endif //DEMOGAME_LOADINGLAYER_H
