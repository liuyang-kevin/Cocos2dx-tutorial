//
// Created by fifthdimension on 2020/1/29.
//

#include "LoginScene.h"
#include "LoadingLayer.h"
#include "reader/CreatorReader.h"


#include "cocostudio/CocoStudio.h"

using namespace cocostudio;
#define _LOAD_RES_NUM_        16

Scene *LoginScene::createScene() {
    auto scene = Scene::create();
    auto layer = LoginScene::create();
    scene->addChild(layer);
    return scene;
}

void LoginScene::onMsg(int nMsgID, void *pInfo, int nSize) {
    MsgReceiver::onMsg(nMsgID, pInfo, nSize);
}

void LoginScene::onEnter() {
    Layer::onEnter();
//    CCLOG("layer的Enter回调函数!");
    do {
        //创建Laoding层
        LoadingLayer *pLoading = LoadingLayer::create();
        CC_BREAK_IF(pLoading == nullptr);
        addChild(pLoading, enZOrderFront + 10000, enTagLoading);

        m_nLoadResNum = 0;
        m_nLoadResTotalNum = _LOAD_RES_NUM_;

        //预加载本层资源
        loadRes();
        return;
    } while (false);
    CCLOG("Func LoginScene::onEnter Error!");
}

void LoginScene::loadRes() {
    Director::getInstance()->getTextureCache()->addImageAsync("ui/serverselect_bg.png",
                                                              CC_CALLBACK_1(LoginScene::onLoadResCallBack, this));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/kulougongshou.ExportJson", this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));

    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/kulouzhanshi.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/mayi.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/bianyikunchong.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/bubing.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/xiaoyin.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/NewProject.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/minren1.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));

    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/kulou_arrow.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));

    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/naili.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/NPC_kakaxi.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/portal.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));

    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/hited_light.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/public_casting.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));
    ArmatureDataManager::getInstance()->addArmatureFileInfoAsync("armature/skill_light_1.ExportJson",
                                                                 this,
                                                                 CC_SCHEDULE_SELECTOR(LoginScene::onLoadArmatureData));

}

void LoginScene::onLoadArmatureData(float percent) {
    CCLOG("==================%f", percent);
    m_nLoadResNum++;
    auto pLoading = dynamic_cast<LoadingLayer *>(getChildByTag(enTagLoading));
    if (pLoading != nullptr) {
        pLoading->setProgress((float) m_nLoadResNum / (float) m_nLoadResTotalNum);
    } else {
        CCLOG("Fun CNFLoginScene::OnLoadArmatureData Error!");
    }

    if (m_nLoadResNum == m_nLoadResTotalNum) {
        CCLOG("m_nLoadResNum == m_nLoadResTotalNum ====%d", (m_nLoadResNum == m_nLoadResTotalNum));
//        this->runAction(Sequence::create(DelayTime::create(1.f), CC_CALLBACK_0(LoginScene::switchSceneUI, this), NULL));

        this->runAction(Sequence::create(
                DelayTime::create(3.f),
                CallFunc::create(CC_CALLBACK_0(LoginScene::switchSceneUI, this)),
                NULL));
    }
    if (percent >= 1) {
        CCLOG("addArmatureFileInfoAsync over");
    }
}

void LoginScene::switchSceneUI() {
    CCLOG("=====switchSceneUI======");
    do {
        //移除Laoding层
        removeChildByTag(enTagLoading, true);
//        auto pLoading = dynamic_cast<LoadingLayer *>(getChildByTag(enTagLoading));
//        if (pLoading != nullptr){
//            removeChild(pLoading,true);
////            removeChildByTag(enTagLoading, true);
//        }
        /************************************************************************/
        /*				2.联网：得到服务器ID                                                                     */
        /************************************************************************/
        m_nCurrentServerID = 16;
        m_nServerTotalNum = 31;

        //创建登录UI层
        auto pLoginUiLayer = Layer::create();
        CC_BREAK_IF(pLoginUiLayer == nullptr);

        ui::Widget *pLoginWidget = GUIReader::getInstance()->widgetFromJsonFile("NormalLogin.json");

//        auto pLoginWidget = dynamic_cast<Layout *>(GUIReader::shareReader()->widgetFromJsonFile("NormalLogin.json"));
        CC_BREAK_IF(pLoginWidget == nullptr);
        pLoginWidget->setName("LoginLayer");
        pLoginUiLayer->addChild(pLoginWidget);

        pLoginWidget->setContentSize(getContentSize());

        addChild(pLoginUiLayer, enZOrderBack, enTagStudioLoginLayer);
        testCC();

        return;
    } while (false);
    CCLOG("Fun CNFLoginScene::InitSceneUI Error!");
}

void testCC() {
    creator::CreatorReader *reader = creator::CreatorReader::createWithFilename("creator/LoginWidget.ccreator");

    // will create the needed spritesheets + design resolution
    reader->setup();

    // get the scene graph
    Scene * scene = reader->getSceneGraph();

    // ...and use it
    Director::getInstance()->replaceScene(scene);
}

bool LoginScene::init() {
    return Layer::init();
}

//资源加载回调
void LoginScene::onLoadResCallBack(Texture2D *texture) {
    do {
        m_nLoadResNum++;

        //得到Laoding层
        auto *pLoading = dynamic_cast<LoadingLayer *>(getChildByTag(enTagLoading));
        CC_BREAK_IF(pLoading == nullptr);
        pLoading->setProgress((float) m_nLoadResNum / (float) m_nLoadResTotalNum);

        if (m_nLoadResNum == m_nLoadResTotalNum) {
            this->runAction(
                    Sequence::create(DelayTime::create(2.f), CC_CALLBACK_0(LoginScene::switchSceneUI, this), NULL)
            );
        }

        return;
    } while (false);
    CCLOG("Fun CNFLoginScene::OnLoadRecCallBack Error!");
}
