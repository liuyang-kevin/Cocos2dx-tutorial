//
// Created by fifthdimension on 2020/1/28.
//
#ifndef DEMOGAME_LOGOSCENE_H
#define DEMOGAME_LOGOSCENE_H

#include "cocos2d.h"

USING_NS_CC;

class LogoScene : public Layer {
public:
    static Scene* createScene();
    CREATE_FUNC(LogoScene);

protected:
    bool init() override;
    void onChangeScene();
};


#endif //DEMOGAME_LOGOSCENE_H
