//
// Created by fifthdimension on 2020/1/29.
//
#include "LoadingLayer.h"
#include "Common/Common.h"

USING_NS_CC;

void LoadingLayer::setProgress(float fRate) {
    do {
        //同步进度条
        auto *pProLoadRec = dynamic_cast<ProgressTimer *>(getChildByTag(enTagPro));
        if (pProLoadRec != nullptr)
            pProLoadRec->setPercentage(fRate * 100);

        //同步光点
        auto *pLight = dynamic_cast<Sprite *>(getChildByTag(enTagLight));
        if (pLight != nullptr)
            pLight->setPositionX(pProLoadRec->getPositionX() + pProLoadRec->getContentSize().width * (fRate - 0.5f));

        //若加载完成
        if (fRate >= 1) {
            ValueMap readValueMap = FileUtils::getInstance()->getValueMapFromFile("ui_xml/loading_xml.xml");

            //加载信息label
            auto *pLabelLoading = dynamic_cast<Label *>(getChildByTag(enTagLabel));
            pLabelLoading->setString(readValueMap["loading_end"].asString());
        }

        return;
    } while (false);
    CCLOG("Fun CNFLoadingLayer::SetPro Error!");
}

bool LoadingLayer::init() {
    do {
        //初始化父类
        CC_BREAK_IF(LayerColor::initWithColor(Color4B(0, 0, 0, 255)) == false);
        //独占触屏
        _touchListener = EventListenerTouchOneByOne::create();
        _touchListener->autorelease();
        _touchListener->onTouchBegan = CC_CALLBACK_2(LoadingLayer::onTouchBegan, this);
        _touchListener->onTouchMoved = CC_CALLBACK_2(LoadingLayer::onTouchMoved, this);
        _touchListener->onTouchEnded = CC_CALLBACK_2(LoadingLayer::onTouchEnded, this);
        Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(_touchListener, this);

        /************************************************************************/
        /*				背景图片                                                                     */
        /************************************************************************/
        //创建人物图片
        Sprite *pPersonBg = Sprite::create("ui/loading_bg.png");
        CC_BREAK_IF(pPersonBg == nullptr);
        pPersonBg->setPosition(SCREEN_CENTER);
        addChild(pPersonBg, enZOrderBack);

        //创建logo图片
        Sprite *pLogo = Sprite::create("ui/logo_bg.png");
        CC_BREAK_IF(pLogo == nullptr);
        pLogo->setScale(0.95f);
        pLogo->setPosition(Vec2(SCREEN_WIDTH * 0.5f, 410));
        addChild(pLogo, enZOrderBack);


        /************************************************************************/
        /*				进度条                                                                     */
        /************************************************************************/
        //创建加载进度条背景
        Sprite *pProBg = Sprite::create("ui/loading_progress_bg.png");
        CC_BREAK_IF(pProBg == nullptr);
        pProBg->setPosition(Vec2(SCREEN_WIDTH * 0.5f, 100));
        addChild(pProBg, enZOrderMid);

        //创建加载进度条
        ProgressTimer *pProLoadRec = ProgressTimer::create(Sprite::create("ui/loading_progress_bar.png"));
        CC_BREAK_IF(pProLoadRec == nullptr);
        pProLoadRec->setPosition(pProBg->getPosition());
        pProLoadRec->setType(ProgressTimer::Type::BAR);    //设置进度条类型
        pProLoadRec->setMidpoint(Vec2(0, 0));                //靠左
        pProLoadRec->setBarChangeRate(Vec2(1, 0));        //Y轴不缩放
        pProLoadRec->setPercentage(0.f);
        addChild(pProLoadRec, enZOrderMid + 1, enTagPro);

        //创建光点
        Sprite *pLight = Sprite::create("ui/loading_progress_light.png");
        CC_BREAK_IF(pLight == nullptr);
        addChild(pLight, enZOrderFront, enTagLight);
        pLight->setPosition(Vec2(pProLoadRec->getPositionX() - pProLoadRec->getContentSize().width * 0.5f,
                                 pProLoadRec->getPositionY()));


        /************************************************************************/
        /*					label                                                                    */
        /************************************************************************/
        ValueMap readValueMap = FileUtils::getInstance()->getValueMapFromFile("ui_xml/loading_xml.xml");
        //加载信息label
        auto pLabelLoading = Label::createWithTTF(readValueMap["loading_now"].asString(), "fonts/arial.ttf", 10.0f);
//        labelLoading->setTag(TABLE_LABEL_TAG);
        pLabelLoading->setPosition(pProLoadRec->getPosition());
        addChild(pLabelLoading, enZOrderMid + 2, enTagLabel);

        return true;
    } while (false);
    CCLOG("Func LoadingLayer::init Error!");
    return false;
}

bool LoadingLayer::onTouchBegan(Touch *pTouch, Event *pEvent) {
    return true;
}

void LoadingLayer::onTouchMoved(Touch *pTouch, Event *pEvent) {
    Layer::onTouchMoved(pTouch, pEvent);
}

void LoadingLayer::onTouchEnded(Touch *pTouch, Event *pEvent) {
    Layer::onTouchEnded(pTouch, pEvent);
}

void LoadingLayer::onExit() {
    Director::getInstance()->getEventDispatcher()->removeEventListener(_touchListener);
    LayerColor::onExit();
}
