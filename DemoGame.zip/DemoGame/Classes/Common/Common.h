//
// Created by fifthdimension on 2020/1/28.
//

#ifndef DEMOGAME_COMMON_H
#define DEMOGAME_COMMON_H

#include <vector>

#include "cocos2d.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

//z轴
enum {
    enZOrderBack = 100,
    enZOrderMid = 100000,
    enZOrderFront = 300000,
};

#define SCREEN_WIDTH        Director::getInstance()->getWinSize().width    //屏幕宽(指定分辨率)
#define SCREEN_HEIGHT        480
#define SCREEN_CENTER        Vec2(SCREEN_WIDTH*0.5f,SCREEN_HEIGHT*0.5f)            //屏幕中心


//消息接收
class MsgReceiver {
public:
    virtual void onMsg(int nMsgID, void *pInfo, int nSize) {}
};

#endif //DEMOGAME_COMMON_H
